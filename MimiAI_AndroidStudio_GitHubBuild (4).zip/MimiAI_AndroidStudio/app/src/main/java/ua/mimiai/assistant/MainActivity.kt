package ua.mimiai.assistant

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { MimiScreen() }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("uk", "UA"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setSpeechRate(0.94f)
            tts?.setPitch(1.12f)
            if (!ttsReady) Toast.makeText(this, "Встанови українські голосові дані в налаштуваннях Android.", Toast.LENGTH_LONG).show()
        }
    }

    private fun say(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mimi_reply")
        else Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }

    private fun launchApp(packageName: String, label: String): String {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        return if (launch != null) {
            startActivity(launch)
            "Відкриваю $label."
        } else "Не знайшла $label на цьому телефоні."
    }

    private fun handleLocalCommand(raw: String): String? {
        val command = raw.lowercase(Locale("uk", "UA")).trim()
        return when {
            command.contains("youtube") || command.contains("ютуб") -> launchApp("com.google.android.youtube", "YouTube")
            command.contains("telegram") || command.contains("телеграм") -> launchApp("org.telegram.messenger", "Telegram")
            command.contains("whatsapp") || command.contains("ватсап") -> launchApp("com.whatsapp", "WhatsApp")
            command.contains("chrome") || command.contains("браузер") || command.contains("інтернет") -> launchApp("com.android.chrome", "браузер")
            command.contains("пошта") || command.contains("gmail") -> launchApp("com.google.android.gm", "Gmail")
            command.contains("подзвони") || command.contains("зателефонуй") || command.contains("дзвінок") -> {
                val digits = raw.filter { it.isDigit() || it == '+' }
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")))
                "Відкриваю набір номера. Перевір номер і сам натисни виклик."
            }
            command.contains("напиши смс") || command.contains("відправ смс") || command.contains("надішли смс") -> {
                val digits = raw.filter { it.isDigit() || it == '+' }
                startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$digits")).putExtra("sms_body", "Привіт!"))
                "Відкриваю SMS. Перевір номер і текст та натисни «Надіслати»."
            }
            command.contains("привіт") || command.contains("вітаю") -> "Привіт-привіт! Я Мімі. Рада тебе бачити! 💗"
            command.contains("як тебе звати") -> "Мене звати Мімі. Я твоя маленька помічниця!"
            command.contains("дякую") -> "Будь ласка! Завжди рада допомогти."
            command.contains("поглад") -> "Мур-мур! Як приємно! Погладь мене ще раз! 💕"
            else -> null
        }
    }

    @Composable
    private fun MimiScreen() {
        var command by remember { mutableStateOf("") }
        var reply by remember { mutableStateOf("Привіт! Я Мімі. Торкнися мене або скажи, чим допомогти.") }
        var overlayOn by remember { mutableStateOf(false) }
        var serverUrl by remember { mutableStateOf(getPreferences(MODE_PRIVATE).getString("server_url", "") ?: "") }
        var busy by remember { mutableStateOf(false) }
        var pets by remember { mutableIntStateOf(0) }
        val scope = rememberCoroutineScope()

        val speechLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                command = spoken
                submitMessage(spoken, serverUrl, scope, { reply = it }, { busy = it })
            }
        }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) startVoice { speechLauncher.launch(it) }
            else Toast.makeText(this, "Для голосових команд потрібен дозвіл на мікрофон.", Toast.LENGTH_SHORT).show()
        }

        val transition = rememberInfiniteTransition(label = "mimi_idle")
        val floatY by transition.animateFloat(
            initialValue = -5f, targetValue = 5f,
            animationSpec = infiniteRepeatable(tween(1700), RepeatMode.Reverse),
            label = "float"
        )
        val tilt by transition.animateFloat(
            initialValue = -1.2f, targetValue = 1.2f,
            animationSpec = infiniteRepeatable(tween(2400), RepeatMode.Reverse),
            label = "tilt"
        )

        MaterialTheme(colorScheme = lightColorScheme(
            primary = Color(0xFFCE5C91), secondary = Color(0xFFED9DBB),
            background = Color(0xFFFFF1F6), surface = Color.White
        )) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFFFFF1F6)) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Mimi AI", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Color(0xFFB63D78))
                    Text("Твоя українськомовна помічниця", color = Color(0xFF8D5570))
                    Spacer(Modifier.height(8.dp))
                    Box(contentAlignment = Alignment.TopEnd) {
                        Image(
                            painter = painterResource(R.drawable.assistant),
                            contentDescription = "Мімі — аніме-помічниця",
                            modifier = Modifier.fillMaxWidth().height(330.dp)
                                .offset(y = floatY.dp).rotate(tilt)
                                .clickable {
                                    pets++
                                    val petReply = listOf("Мур-мур! 💗", "Хі-хі, лоскотно!", "Я щаслива! Погладь ще!", "Няв! Дякую за ласку!")[pets % 4]
                                    reply = petReply
                                    say(petReply)
                                }
                        )
                        Text("💗 $pets", color = Color(0xFFB63D78), fontWeight = FontWeight.Bold)
                    }
                    Text("Торкнися зображення, щоб погладити Мімі", color = Color(0xFF9C6680), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(if (busy) "Мімі думає…" else "Мімі каже:", fontWeight = FontWeight.Bold, color = Color(0xFFB63D78))
                            Spacer(Modifier.height(6.dp))
                            Text(reply)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = command, onValueChange = { command = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Напиши Мімі") },
                        placeholder = { Text("Наприклад: Розкажи щось цікаве") },
                        shape = RoundedCornerShape(16.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                else startVoice { speechLauncher.launch(it) }
                            },
                            modifier = Modifier.weight(1f)
                        ) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(5.dp)); Text("Говорити") }
                        Button(
                            onClick = {
                                if (command.isNotBlank()) submitMessage(command, serverUrl, scope, { reply = it }, { busy = it })
                            },
                            enabled = !busy && command.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Text("Надіслати") }
                    }
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = serverUrl, onValueChange = { serverUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Адреса твого AI-сервера (необов'язково)") },
                        placeholder = { Text("https://твій-сервер.example") },
                        singleLine = true
                    )
                    Text("Ключ API зберігається тільки на сервері, не в телефоні.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF8D5570))
                    Button(
                        onClick = {
                            getPreferences(MODE_PRIVATE).edit().putString("server_url", serverUrl.trim().trimEnd('/')).apply()
                            reply = "Адресу сервера збережено на цьому телефоні."
                            say(reply)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Зберегти адресу AI-сервера") }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (!Settings.canDrawOverlays(this@MainActivity)) {
                                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                                Toast.makeText(this@MainActivity, "Дозволь «Показ поверх інших програм», потім повернись.", Toast.LENGTH_LONG).show()
                            } else {
                                ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, FloatingAssistantService::class.java))
                                overlayOn = true
                                reply = "Я поруч! Можеш перетягувати мене по екрану й довго натискати, щоб погладити. 💗"
                                say(reply)
                            }
                        }, modifier = Modifier.fillMaxWidth()
                    ) { Icon(Icons.Default.Favorite, null); Spacer(Modifier.width(8.dp)); Text(if (overlayOn) "Мімі активна поверх програм" else "Показувати Мімі поверх програм") }
                    OutlinedButton(onClick = {
                        stopService(Intent(this@MainActivity, FloatingAssistantService::class.java))
                        overlayOn = false
                        reply = "Я сховалася. До зустрічі! 💗"
                    }, modifier = Modifier.fillMaxWidth()) { Text("Сховати персонажа") }
                    Spacer(Modifier.height(12.dp))
                    Text("Команди: «Відкрий YouTube», «Відкрий Telegram», «Подзвони +380…», «Напиши SMS +380…»", color = Color(0xFF79586A), style = MaterialTheme.typography.bodySmall)
                    Text("Для довільної розмови запусти AI-сервер і вкажи його HTTPS-адресу вище.", color = Color(0xFF79586A), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    private fun submitMessage(
        text: String,
        serverUrl: String,
        scope: kotlinx.coroutines.CoroutineScope,
        onReply: (String) -> Unit,
        onBusy: (Boolean) -> Unit
    ) {
        val local = try { handleLocalCommand(text) } catch (e: Exception) { "Не вдалося виконати дію: ${e.localizedMessage}" }
        if (local != null) {
            onReply(local); say(local); return
        }
        if (serverUrl.isBlank()) {
            val msg = "Я поки не підключена до AI-сервера. Можу відкрити програми, підготувати дзвінок або SMS. Для вільної розмови введи HTTPS-адресу сервера."
            onReply(msg); say(msg); return
        }
        onBusy(true)
        scope.launch {
            val answer = AiClient.chat(serverUrl, text)
            onBusy(false)
            onReply(answer)
            say(answer)
        }
    }

    private fun startVoice(launch: (Intent) -> Unit) {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uk-UA")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "uk-UA")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажи команду для Мімі")
        }
        try { launch(intent) }
        catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "На телефоні немає служби розпізнавання голосу.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
