package ua.mimiai.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    suspend fun chat(baseUrl: String, message: String): String = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val endpoint = baseUrl.trimEnd('/') + "/chat"
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 45000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val body = JSONObject().put("message", message).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (connection.responseCode !in 200..299) {
                val detail = runCatching { JSONObject(response).optString("error") }.getOrNull().orEmpty()
                "Сервер повернув помилку ${connection.responseCode}. $detail"
            } else {
                JSONObject(response).optString("reply").ifBlank { "Сервер не повернув текст відповіді." }
            }
        } catch (e: Exception) {
            "Не вдалося зв'язатися з AI-сервером. Перевір інтернет та адресу сервера. ${e.localizedMessage ?: ""}"
        } finally {
            connection?.disconnect()
        }
    }
}
