package ua.mimiai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import java.util.Locale

class FloatingAssistantService : Service(), TextToSpeech.OnInitListener {
    private lateinit var windowManager: WindowManager
    private var avatar: ImageView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var idleAnimator: ObjectAnimator? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createNotificationChannel()
        startForeground(41, buildNotification())
        showAvatar()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("uk", "UA"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setPitch(1.15f)
            tts?.setSpeechRate(0.92f)
        }
    }

    private fun petReaction() {
        avatar?.animate()?.cancel()
        avatar?.animate()?.scaleX(1.10f)?.scaleY(1.10f)?.setDuration(150)?.withEndAction {
            avatar?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(220)?.start()
        }?.start()
        if (ttsReady) tts?.speak("Мур-мур! Як приємно! Дякую за погладжування! 💗", TextToSpeech.QUEUE_FLUSH, null, "pet")
        Toast.makeText(this, "Мур-мур! 💗", Toast.LENGTH_SHORT).show()
    }

    private fun showAvatar() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val image = ImageView(this).apply {
            setImageResource(R.drawable.assistant)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Мімі. Перетягни мене; торкнись або довго натисни, щоб погладити."
            setOnTouchListener(object : View.OnTouchListener {
                private var downX = 0f
                private var downY = 0f
                private var startX = 0
                private var startY = 0
                private var downAt = 0L
                private var moved = false
                override fun onTouch(view: View, event: MotionEvent): Boolean {
                    val params = layoutParams ?: return false
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = event.rawX; downY = event.rawY
                            startX = params.x; startY = params.y
                            downAt = System.currentTimeMillis()
                            moved = false
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (event.rawX - downX).toInt()
                            val dy = (event.rawY - downY).toInt()
                            if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                            params.x = startX + dx
                            params.y = startY + dy
                            try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!moved) {
                                if (System.currentTimeMillis() - downAt >= 450) petReaction()
                                else {
                                    val open = Intent(this@FloatingAssistantService, MainActivity::class.java)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                    startActivity(open)
                                }
                            }
                            return true
                        }
                    }
                    return true
                }
            })
        }
        val size = (190 * resources.displayMetrics.density).toInt()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            size, (size * 1.25f).toInt(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 160 }
        layoutParams = params
        avatar = image
        idleAnimator = ObjectAnimator.ofFloat(image, View.TRANSLATION_Y, -7f, 7f).apply {
            duration = 1900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        try { windowManager.addView(image, params) } catch (_: Exception) { stopSelf() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("mimi_overlay", "Mimi AI — плаваюча помічниця", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, "mimi_overlay")
            else @Suppress("DEPRECATION") Notification.Builder(this)
        val openApp = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 42, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return builder.setContentTitle("Mimi AI працює")
            .setContentText("Плаваюча Мімі активна. Натисни на сповіщення, щоб відкрити помічницю.")
            .setContentIntent(pending)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        idleAnimator?.cancel()
        idleAnimator = null
        avatar?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        avatar = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
