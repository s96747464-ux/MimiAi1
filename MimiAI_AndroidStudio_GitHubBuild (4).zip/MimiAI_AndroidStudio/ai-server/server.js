import express from "express";

const app = express();
app.use(express.json({ limit: "32kb" }));

const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || "gpt-5.5";
if (!apiKey) {
  console.error("Set OPENAI_API_KEY in the server environment. Never put it in the Android app.");
  process.exit(1);
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "Mimi AI" }));

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message || message.length > 4000) {
      return res.status(400).json({ error: "Повідомлення порожнє або задовге (максимум 4000 символів)." });
    }

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        instructions: [
          "Ти Мімі — доброзичлива, мила, ввічлива українськомовна помічниця.",
          "Відповідай природною українською, тепло і стисло.",
          "Ти не можеш самостійно натискати кнопки телефону або виконувати системні дії.",
          "Не стверджуй, що відкрила застосунок, надіслала SMS чи здійснила дзвінок."
        ].join(" "),
        input: message,
        max_output_tokens: 500
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      console.error("OpenAI API error:", upstream.status, data?.error?.message || "unknown error");
      return res.status(502).json({ error: "Помилка AI-провайдера. Перевір ключ, доступ до моделі та оплату API." });
    }

    const reply = (data.output || [])
      .filter(item => item.type === "message")
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n")
      .trim();

    res.json({ reply: reply || "Не вдалося сформувати відповідь. Спробуй ще раз." });
  } catch (error) {
    console.error("Mimi server error:", error?.message || error);
    res.status(502).json({ error: "AI-сервер тимчасово недоступний." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`Mimi AI server listening on ${port}`));
